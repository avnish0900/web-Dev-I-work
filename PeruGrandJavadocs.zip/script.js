function validateFname(){
    var regName = /^[a-zA-Z]/;
    var name = document.getElementById('fname').value;
    if(!regName.test(name)){
        alert('Please enter your first name.');
        document.getElementById('fname').focus();
        return false;
    }else{
        return true;
    }
}

function validateLname(){
    var regName = /^[a-zA-Z]/;
    var name = document.getElementById('lname').value;
    if(!regName.test(name)){
        alert('Please enter your last name.');
        document.getElementById('lname').focus();
        return false;
    }else{
        return true;
    }
}

const validateEmail = (email) => {
  return String(email)
    .toLowerCase()
    .match(
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
};

function validatemail(){
    var mail = document.getElementById('email').value;
    if(!validateEmail(mail)){
        alert('Please enter your email correctly.');
        document.getElementById('email').focus();
        return false;
    }else{
        return true;
    }
}

function phonenumber(){
  var b = document.getElementById('phone').value;
  var a = /^\d{10}$/;  
  if (a.test(b)){
    return true;
  }
  else{
    alert('Please enter your phone no correctly.');
    document.getElementById('phone').focus();
    return false;
  }
}

let inputs = document.querySelectorAll('input'),
selectedt = false;
selectedf = false;

function check(){
  for(const input of inputs){
    if(input.type === 'radio' && input.checked){
      if(input.value == "yes"){
        selectedt = true;
        break;
      }
      if(input.value == "no"){
        selectedf = true;
        break;
      }
    }
  }
  if(selectedt){
    var x = document.getElementById('urll').value;
    x = x.trim();
    if(x.length > 1){
      return true;
    }
    else{
      alert('Please enter url.');
      document.getElementById('urll').focus();
    }
  }
  if(selectedf){
    return true;
  }
  else{
    alert("You didn't select any option");
  }
}


function solve(){
  if(validateFname() && validateLname() && validatemail() && phonenumber() && check()){
    alert('form submitted successfully');
  }
  else{
  }
}